A Pen created at CodePen.io. You can find this one at http://codepen.io/athenagranger/pen/qRpjEX.

 done with this tutorial: https://scotch.io/tutorials/building-a-morphing-hamburger-menu-with-css