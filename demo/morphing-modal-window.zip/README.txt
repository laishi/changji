A Pen created at CodePen.io. You can find this one at http://codepen.io/codyhouse/pen/vEVjJg.

 A call-to-action button that animates and turns into a full-size modal window.

The final result is powered by a combination of CSS transition and transformations, jQuery and Velocity.js.

Tutorial & Download on CodyHouse:
http://codyhouse.co/gem/morphing-modal-window/