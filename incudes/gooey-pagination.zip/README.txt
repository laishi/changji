A Pen created at CodePen.io. You can find this one at http://codepen.io/lbebber/pen/lFdHu.

 Gooey pagination effect based on a dribbble by Kreativa Studio: https://dribbble.com/shots/1676635-Page-scroll-concept