A Pen created at CodePen.io. You can find this one at http://codepen.io/tylernj42/pen/LEKedz.

 Proof of concept rotating slider.  Uses clip-path and lots of math.